const CONFIG = {
    //Prod Link
    GOOGLE_SHEET_URL_DENOMINATIONS: 'https://script.google.com/macros/s/AKfycbyPA-Tg-g8MhrdMZPNIKFfNvU691amfVEd751V-PwVh7FmZm_HmPBiVhLSr8d25R1qUlg/exec',
    //QA Link
    //GOOGLE_SHEET_URL_CASH_COUNTER: 'https://script.google.com/macros/s/AKfycbxViPXKVueaCVxBsjNk2ndAFDWlWBipghlzUC_-u5ZlI2F_zrG6xL27eyIGjRF6NuoOPA/exec',

    //Prod Link
    GOOGLE_SHEET_URL_CASHEW: 'https://script.google.com/macros/s/AKfycbzoeqSVhH16JdAHDQIiFn9f73jRa3NZQNP2feac0zpn_gTclMinVsA41MzFNlsf6-Df0w/exec',
    //QA Link
    //GOOGLE_SHEET_URL_CASHEW: 'https://script.google.com/macros/s/AKfycbz7-TPG6goJrAXw-2TZSebXf8Y_iAgKReHsQNKHg2ts01ZfILc82mX1-u2SqeTukBayRQ/exec'

    //Prod Link
    GOOGLE_SHEET_URL_MSI: 'https://script.google.com/macros/s/AKfycbymQCgffCJ_XCrKk1RjgZlVTfquqzHW_n3pPYNNrINeDsTjJy0Yx18ZfgOmr6qSsCcb/exec',

    //Prod Link
    GOOGLE_SHEET_URL_RENT: 'https://script.google.com/macros/s/AKfycbzpUu7Uf6y7BZd5VUqsl40aMMblhd8CR36sycoYEBPOuumM4QI7ePdSaNWDvF-_x1nKvA/exec'
};